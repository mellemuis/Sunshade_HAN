#include <iostream>
using namespace std;

#ifndef MOTOR_H
#define MOTOR_H

class Motor
{
public:

  //Empty Constructor
  Motor();

  //Methods
  void Extend();
  void Retract();


};

#endif // MOTOR_H
