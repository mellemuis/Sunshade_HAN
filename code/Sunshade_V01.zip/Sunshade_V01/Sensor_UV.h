#include <iostream>
using namespace std;

#include "Sensors.h"

#ifndef SENSOR_UV_H
#define SENSOR_UV_H

class Sensor_UV: public Sensors
{
public:

  //Empty Constructor
  Sensor_UV();

  //Methods
  void setUVindex(int value);
  int getUVindex();

  void Measure();

private:

  //Sensor value
  int UVindex = 6;

  void initAttributes();

};

#endif // SENSOR_UV_H
