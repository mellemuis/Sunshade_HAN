#include <iostream>
using namespace std;

#include "Sensors.h"

#ifndef SENSOR_INSIDE_H
#define SENSOR_INSIDE_H

class Sensor_inside: public Sensors
{
public:

  //Empty Constructor
  Sensor_inside();

  Sensor_inside Sensor_insideObject();

  //Methods
  void setRoomtemperature(int value);
  int getRoomtemperature();

  void setCurrentroomtemperature(int value);
  int getCurrentroomtemperature();

  void Measure();

private:

  //Sensor values                                       //Change value to change sunshade's state (extended or retracted)
  int Roomtemperature = 18;                             //Set room temperature by user
  int Currentroomtemperature = 19;

  void initAttributes();

};

#endif // SENSOR_INSIDE_H
