#include <iostream>
using namespace std;

#ifndef SENSORS_H
#define SENSORS_H

class Sensors
{
public:

  virtual void Measure() =0;

  //Empty Constructor
  Sensors();

  //Empty Destructor
  virtual ~Sensors();

};

#endif // SENSORS_H
