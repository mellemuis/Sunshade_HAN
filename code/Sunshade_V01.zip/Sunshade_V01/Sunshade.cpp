#include <iostream>
using namespace std;

#include "Sunshade.h"

// Constructors/Destructors


Sunshade::Sunshade()
{
 initAttributes();
}

// Methods
void Sunshade::initAttributes()
{
}

void Sunshade::ChecksensorValues()
{
    if(
       Sensor_inside::getCurrentroomtemperature() >= Sensor_inside::getRoomtemperature()
       && Sensor_Outside::getRainfall() <= 3
       && Sensor_Outside::getWind() <= 25
       && Sensor_Outside::getLightintensity() >28000
       && Sensor_UV::getUVindex() >= 5
       && State_extended != true
      )
        {
        Motor::Extend();
        }
    else
        {
        Motor::Retract();
        }
}

void Sunshade::setState_Extended(int value)
{
    State_extended = value;
}

bool Sunshade::getState_Extended()
{
    return State_extended;
}

void Sunshade::setState_Retracted(int value)
{
    State_extended = value;
}

bool Sunshade::getState_Retracted()
{
    return State_extended;
}


