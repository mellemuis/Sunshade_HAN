#include <iostream>
using namespace std;

#include "Motor.h"

Motor::Motor()
{
}

void Motor::Extend(){
    cout << "Sunshade is extending" << endl;
}

void Motor::Retract(){
    cout << "Sunshade is retracting" << endl;
}






